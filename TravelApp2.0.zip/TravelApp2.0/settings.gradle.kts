pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // 1. 阿里云镜像
        maven { url = uri("https://maven.aliyun.com/repository/public") }

        // 2. Bmob 官方仓库
        maven { url = uri("https://raw.github.com/bmob/bmob-android-sdk/master") }

        google()
        mavenCentral()

        maven { url = uri("https://jitpack.io") }
    }
}
rootProject.name = "TravelApp"
include(":app")