package com.example.travelapp;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        TextView tvTitle = findViewById(R.id.tv_detail_title); // 标题
        ImageView ivImage = findViewById(R.id.iv_detail_image); // 大图
        TextView tvDesc = findViewById(R.id.tv_detail_desc);   // 简介

        // 返回
        if (findViewById(R.id.btn_back) != null) {
            findViewById(R.id.btn_back).setOnClickListener(v -> finish());
        }

        // 2. 接收数据 (对应 EarthActivity 发出的 "暗号")
        String title = getIntent().getStringExtra("title");
        String desc = getIntent().getStringExtra("desc");
        int imageId = getIntent().getIntExtra("image_id", R.mipmap.ic_launcher); // 默认图
        float score = getIntent().getFloatExtra("score", 5.0f);

        // Debug
        // Toast.makeText(this, "收到: " + title, Toast.LENGTH_SHORT).show();

        // 3. 显示数据
        if (tvTitle != null) tvTitle.setText(title != null ? title : "未知地点");
        if (tvDesc != null) tvDesc.setText(desc != null ? desc : "暂无简介");
        if (ivImage != null) ivImage.setImageResource(imageId);
    }
}