package com.example.travelapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EarthActivity extends AppCompatActivity {

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earth);

        // 返回按钮
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();

        // JS 支持
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // 允许混合内容
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // 接口：让 HTML 能调用 Android 的代码 window.Android
        webView.addJavascriptInterface(new WebAppInterface(), "Android");

        // 加载本地 HTML
        webView.loadUrl("file:///android_asset/earth.html");
    }

    // 定义交互接口类
    public class WebAppInterface {
        @JavascriptInterface
        public void onEarthClick(String destName) {
            runOnUiThread(() -> {
                Intent intent = new Intent(EarthActivity.this, DetailActivity.class);

                fillIntentData(intent, destName);

                startActivity(intent);
            });
        }
    }

    private void fillIntentData(Intent intent, String name) {
        intent.putExtra("title", name);

        // 默认数据 (防止匹配不到时显示空白)
        int imgId = R.mipmap.ic_launcher;
        String desc = "这里有未知的风景，等待你去探索...";
        float rating = 4.5f;

        // === 亚洲 ===
        if (name.contains("京都")) {
            imgId = getResId("p_kyoto");
            desc = "漫步花见小路，在千年古刹中聆听风铃，感受唐风宋韵的宁静...";
            rating = 4.9f;
        } else if (name.contains("大理")) {
            imgId = getResId("p_dali");
            desc = "去有风的地方，看苍山洱海。在民宿露台发呆，享受没有闹钟的慢生活...";
            rating = 4.8f;
        } else if (name.contains("北京") || name.contains("故宫")) {
            imgId = getResId("beijing"); // 如果没有这张图，会自动用默认图
            desc = "红墙黄瓦，岁月悠长。在紫禁城看一场初雪，感受六百年的历史回响。";
            rating = 5.0f;
        } else if (name.contains("曼谷")) {
            imgId = getResId("bangkok");
            desc = "千佛之国，并在湄南河畔的夜市里，寻找最地道的冬阴功汤。";
            rating = 4.6f;
        } else if (name.contains("迪拜")) {
            imgId = getResId("dubai");
            desc = "一半是海水，一半是火焰。在世界最高塔俯瞰沙漠奇迹。";
            rating = 4.7f;
        }

        // === 欧洲 ===
        else if (name.contains("巴黎")) {
            imgId = getResId("p2"); // 假设巴黎你之前用的是 p2
            desc = "塞纳河畔的晚风，埃菲尔铁塔的日落，这里是全世界最浪漫的角落。";
            rating = 4.8f;
        } else if (name.contains("瑞士")) {
            imgId = getResId("p_swiss");
            desc = "坐上红色列车穿梭在雪山与森林之间，仿佛置身现实版童话世界。";
            rating = 5.0f;
        } else if (name.contains("伦敦")) {
            imgId = getResId("london");
            desc = "大本钟的钟声敲响，在贝克街寻找福尔摩斯的踪迹，体验英伦绅士风度。";
            rating = 4.7f;
        } else if (name.contains("冰岛")) {
            imgId = getResId("iceland");
            desc = "世界的尽头，冷酷仙境。追逐欧若拉女神的裙摆，体验极致的孤独与美丽。";
            rating = 5.0f;
        } else if (name.contains("圣托里尼")) {
            imgId = getResId("greece");
            desc = "蓝白交织的梦幻岛屿，看世界上最美的夕阳跌入爱琴海。";
            rating = 4.9f;
        }

        else if (name.contains("马尔代夫")) {
            imgId = getResId("p_maldives");
            desc = "上帝抛洒的项链。住进水上屋，醒来就能跳进果冻色的海里。";
            rating = 5.0f;
        } else if (name.contains("纽约")) {
            imgId = getResId("newyork");
            desc = "不夜城的光怪陆离，时代广场的霓虹闪烁，感受世界的脉搏。";
            rating = 4.6f;
        } else if (name.contains("悉尼")) {
            imgId = getResId("sydney");
            desc = "在歌剧院前吹海风，在邦迪海滩冲浪，南半球的阳光格外灿烂。";
            rating = 4.7f;
        } else if (name.contains("开罗")) {
            imgId = getResId("cairo");
            desc = "尼罗河畔的千年呼唤，站在金字塔下，感叹人类文明的渺小与伟大。";
            rating = 4.8f;
        }

        intent.putExtra("image_id", imgId);
        intent.putExtra("desc", desc);
        intent.putExtra("score", rating);
    }

    // 根据名字安全获取图片ID
    private int getResId(String imageName) {
        int id = getResources().getIdentifier(imageName, "drawable", getPackageName());
        if (id == 0) {
            // 如果找不到这张图，就返回默认图标，防止闪退
            return R.mipmap.ic_launcher;
        }
        return id;
    }
}