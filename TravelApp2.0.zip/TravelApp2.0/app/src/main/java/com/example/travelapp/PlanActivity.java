package com.example.travelapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.UpdateListener;

public class PlanActivity extends AppCompatActivity {
    private ListView lvPlans;
    // 存查询到的原始数据，方便点击时获取详情
    private List<TravelPlan> rawPlans = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);

        lvPlans = findViewById(R.id.lv_plans);
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        findViewById(R.id.btn_add_plan).setOnClickListener(v ->
                startActivity(new Intent(this, PlanEditorActivity.class)));

        // 点击修改
        lvPlans.setOnItemClickListener((parent, view, position, id) -> {
            TravelPlan plan = rawPlans.get(position);
            Intent intent = new Intent(this, PlanEditorActivity.class);
            // 传递数据给编辑页，实现回显
            intent.putExtra("planId", plan.getObjectId()); // 传 ID
            intent.putExtra("dest", plan.getDestName());
            intent.putExtra("date", plan.getDate());
            intent.putExtra("days", plan.getDays());
            intent.putExtra("note", plan.getNote());
            startActivity(intent);
        });

        // 长按删除
        lvPlans.setOnItemLongClickListener((parent, view, position, id) -> {
            showDeleteDialog(rawPlans.get(position));
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPlansFromCloud();
    }

    private void loadPlansFromCloud() {
        if (!BmobUser.isLogin()) {
            Toast.makeText(this, "请先登录查看云端行程", Toast.LENGTH_SHORT).show();
            return;
        }

        BmobQuery<TravelPlan> query = new BmobQuery<>();
        // 查询当前用户的行程
        query.addWhereEqualTo("author", BmobUser.getCurrentUser());
        query.order("-createdAt");

        query.findObjects(new FindListener<TravelPlan>() {
            @Override
            public void done(List<TravelPlan> list, BmobException e) {
                if (e == null) {
                    rawPlans = list;
                    showList(list);
                } else {
                    Toast.makeText(PlanActivity.this, "加载失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showList(List<TravelPlan> list) {
        List<Map<String, String>> uiList = new ArrayList<>();
        for (TravelPlan plan : list) {
            Map<String, String> map = new HashMap<>();
            map.put("dest", plan.getDestName());
            map.put("info", "出发: " + plan.getDate() + " | " + plan.getDays() + "天");
            uiList.add(map);
        }

        SimpleAdapter adapter = new SimpleAdapter(
                this,
                uiList,
                R.layout.item_plan, // 确保你有 item_plan.xml
                new String[]{"dest", "info"},
                new int[]{R.id.tv_plan_dest, R.id.tv_plan_info}
        );
        lvPlans.setAdapter(adapter);
    }

    private void showDeleteDialog(TravelPlan plan) {
        new AlertDialog.Builder(this)
                .setTitle("删除确认")
                .setMessage("确定要删除去 " + plan.getDestName() + " 的行程吗？")
                .setPositiveButton("删除", (d, w) -> {
                    // 云端删除
                    TravelPlan p = new TravelPlan();
                    p.setObjectId(plan.getObjectId());
                    p.delete(new UpdateListener() {
                        @Override
                        public void done(BmobException e) {
                            if (e == null) {
                                Toast.makeText(PlanActivity.this, "已删除", Toast.LENGTH_SHORT).show();
                                loadPlansFromCloud(); // 刷新列表
                            } else {
                                Toast.makeText(PlanActivity.this, "删除失败", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                })
                .setNegativeButton("取消", null)
                .show();
    }
}