package com.example.travelapp;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // 在这里""之间输入自己的bmob密钥
        cn.bmob.v3.Bmob.initialize(this, "");

        // 淡入
        findViewById(R.id.iv_splash).setAlpha(0f);
        findViewById(R.id.iv_splash).animate().alpha(1f).setDuration(2000).start();

        // 3秒后跳转
        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }, 3000);
    }
}