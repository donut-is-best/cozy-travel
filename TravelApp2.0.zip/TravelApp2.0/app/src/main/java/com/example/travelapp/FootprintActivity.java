package com.example.travelapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class FootprintActivity extends AppCompatActivity {

    private FrameLayout mapContainer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_footprint);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
        mapContainer = findViewById(R.id.map_container);
        ImageView ivMap = findViewById(R.id.iv_world_map);

        if (ivMap != null) {
            ivMap.setOnTouchListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    showAddDialog(event.getX(), event.getY());
                }
                return true;
            });
        }
    }

    private void showAddDialog(float x, float y) {
        final EditText input = new EditText(this);
        input.setHint("这里有什么回忆？");
        new AlertDialog.Builder(this)
                .setTitle("记录足迹")
                .setView(input)
                .setPositiveButton("确定", (d, w) -> {
                    if (!input.getText().toString().isEmpty()) {
                        addPin(x, y, input.getText().toString());
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void addPin(float x, float y, String text) {
        ImageView pin = new ImageView(this);
        pin.setImageResource(R.mipmap.ic_launcher_round); // 建议换成 icon_pin
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(60, 60);
        params.leftMargin = (int) x - 30;
        params.topMargin = (int) y - 30;
        pin.setLayoutParams(params);
        pin.setOnClickListener(v -> Toast.makeText(this, text, Toast.LENGTH_SHORT).show());
        mapContainer.addView(pin);
    }
}