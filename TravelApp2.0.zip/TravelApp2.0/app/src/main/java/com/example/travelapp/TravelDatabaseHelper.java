package com.example.travelapp;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class TravelDatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "travel_cozy.db";
    private static final int DB_VERSION = 1;
    public static final String TABLE_PLANS = "plans";

    public TravelDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_PLANS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "dest_name TEXT, " +
                "date TEXT, " +
                "days INTEGER, " +
                "note TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLANS);
        onCreate(db);
    }
}