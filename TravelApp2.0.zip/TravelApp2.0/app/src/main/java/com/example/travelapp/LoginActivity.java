package com.example.travelapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class LoginActivity extends AppCompatActivity {

    private EditText etUser, etPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUser = findViewById(R.id.et_username);
        etPwd = findViewById(R.id.et_password);

        // 登录按钮
        findViewById(R.id.btn_login).setOnClickListener(v -> doLogin());

        // 注册按钮
        findViewById(R.id.btn_register).setOnClickListener(v -> doRegister());

        // 关闭按钮
        findViewById(R.id.btn_close).setOnClickListener(v -> finish());
    }

    // === 注册逻辑 ===
    private void doRegister() {
        String name = etUser.getText().toString().trim();
        String pwd = etPwd.getText().toString().trim();

        if (name.isEmpty() || pwd.isEmpty()) {
            Toast.makeText(this, "账号或密码不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        BmobUser user = new BmobUser();
        user.setUsername(name);
        user.setPassword(pwd);

        // 调用 Bmob 的注册方法
        user.signUp(new SaveListener<BmobUser>() {
            @Override
            public void done(BmobUser bmobUser, BmobException e) {
                if (e == null) {
                    Toast.makeText(LoginActivity.this, "注册成功！请直接登录", Toast.LENGTH_SHORT).show();

                    doLogin();
                } else {
                    Toast.makeText(LoginActivity.this, "注册失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    // === 处理登录逻辑 ===

    private void doLogin() {
        String name = etUser.getText().toString().trim();
        String pwd = etPwd.getText().toString().trim();

        if (name.isEmpty() || pwd.isEmpty()) {
            Toast.makeText(this, "账号或密码不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        BmobUser user = new BmobUser();
        user.setUsername(name);
        user.setPassword(pwd);

        // 登录提示
        Toast.makeText(this, "正在登录...", Toast.LENGTH_SHORT).show();

        user.login(new SaveListener<BmobUser>() {
            @Override
            public void done(BmobUser bmobUser, BmobException e) {
                if (e == null) {
                    Toast.makeText(LoginActivity.this, "登录成功！", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "登录失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });
    }
}