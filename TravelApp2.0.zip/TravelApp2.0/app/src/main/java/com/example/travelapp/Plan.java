package com.example.travelapp;

public class Plan {
    private int id;
    private String destName;
    private String date;
    private int days;
    private String note;

    public Plan(int id, String destName, String date, int days, String note) {
        this.id = id;
        this.destName = destName;
        this.date = date;
        this.days = days;
        this.note = note;
    }

    // Getter
    public int getId() { return id; }
    public String getDestName() { return destName; }
    public String getDate() { return date; }
    public int getDays() { return days; }
    public String getNote() { return note; }
}