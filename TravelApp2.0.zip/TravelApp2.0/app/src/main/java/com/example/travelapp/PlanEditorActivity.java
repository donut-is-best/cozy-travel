package com.example.travelapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;

public class PlanEditorActivity extends AppCompatActivity {
    private EditText etDest, etDate, etDays, etNote;
    private String planId = null; // 云端数据的 ObjectId (String类型)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan_editor);

        etDest = findViewById(R.id.et_dest);
        etDate = findViewById(R.id.et_date);
        etDays = findViewById(R.id.et_days);
        etNote = findViewById(R.id.et_note);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        // 检查是否有传递过来的 ID (如果有，说明是修改模式)
        // 注意：Bmob 的 ID 是 String 类型的 objectId
        planId = getIntent().getStringExtra("planId");

        if (planId != null) {
            // 如果是修改，我们需要先回显数据
            // 这里为了简单，我们让上一个页面直接把数据传过来，避免再次联网查询
            etDest.setText(getIntent().getStringExtra("dest"));
            etDate.setText(getIntent().getStringExtra("date"));
            etDays.setText(getIntent().getStringExtra("days"));
            etNote.setText(getIntent().getStringExtra("note"));
        }

        findViewById(R.id.btn_save).setOnClickListener(v -> savePlanToCloud());
    }

    private void savePlanToCloud() {
        // 1. 检查登录
        if (!BmobUser.isLogin()) {
            Toast.makeText(this, "请先登录才能保存行程！", Toast.LENGTH_SHORT).show();
            return;
        }

        String dest = etDest.getText().toString();
        String date = etDate.getText().toString();
        String days = etDays.getText().toString();
        String note = etNote.getText().toString();

        if (dest.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "目的地和日期不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        TravelPlan plan = new TravelPlan();
        plan.setDestName(dest);
        plan.setDate(date);
        plan.setDays(days);
        plan.setNote(note);
        plan.setAuthor(BmobUser.getCurrentUser()); // 绑定当前用户

        if (planId == null) {
            // === 新增模式 ===
            Toast.makeText(this, "正在上传云端...", Toast.LENGTH_SHORT).show();
            plan.save(new SaveListener<String>() {
                @Override
                public void done(String objectId, BmobException e) {
                    if (e == null) {
                        Toast.makeText(PlanEditorActivity.this, "添加成功！", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(PlanEditorActivity.this, "添加失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        } else {
            // === 修改模式 ===
            plan.setObjectId(planId); // 这一点很关键，告诉 Bmob 要更新哪条数据
            plan.update(new UpdateListener() {
                @Override
                public void done(BmobException e) {
                    if (e == null) {
                        Toast.makeText(PlanEditorActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(PlanEditorActivity.this, "修改失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }
}