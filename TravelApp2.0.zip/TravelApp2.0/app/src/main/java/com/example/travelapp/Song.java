package com.example.travelapp;

public class Song {
    private String title;
    private String artist;
    private int resId;   //歌
    private int coverResId; //图

    public Song(String title, String artist, int resId, int coverResId) {
        this.title = title;
        this.artist = artist;
        this.resId = resId;
        this.coverResId = coverResId;
    }

    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    public int getResId() { return resId; }
    public int getCoverResId() { return coverResId; }
}