package com.example.travelapp;

import cn.bmob.v3.BmobObject;
import cn.bmob.v3.BmobUser;

// 继承 BmobObject
public class TravelPlan extends BmobObject {
    private String destName;
    private String date;
    private String days;
    private String note;
    private BmobUser author;
    // 空构造函数
    public TravelPlan() {}

    // Getter 和 Setter
    public String getDestName() { return destName; }
    public void setDestName(String destName) { this.destName = destName; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getDays() { return days; }
    public void setDays(String days) { this.days = days; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public BmobUser getAuthor() { return author; }
    public void setAuthor(BmobUser author) { this.author = author; }
}