package com.example.travelapp;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LuckyActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnStart;
    private List<String> cityNames = new ArrayList<>();
    private boolean isRolling = false; // 是否正在滚动
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lucky);

        tvResult = findViewById(R.id.tv_lucky_result);
        btnStart = findViewById(R.id.btn_start_lucky);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        cityNames.add("京都");
        cityNames.add("大理");
        cityNames.add("瑞士");
        cityNames.add("马尔代夫");
        cityNames.add("冰岛");
        cityNames.add("西藏");
        cityNames.add("重庆");
        cityNames.add("巴黎");

        btnStart.setOnClickListener(v -> {
            if (isRolling) {
                isRolling = false;
                btnStart.setText("再试一次");
            } else {
                isRolling = true;
                btnStart.setText("停止 !");
                startRolling();
            }
        });
    }

    private void startRolling() {
        new Thread(() -> {
            final Random random = new Random();
            while (isRolling) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) { e.printStackTrace(); }

                // 随机
                int index = random.nextInt(cityNames.size());
                String name = cityNames.get(index);

                handler.post(() -> tvResult.setText(name));
            }
        }).start();
    }
}