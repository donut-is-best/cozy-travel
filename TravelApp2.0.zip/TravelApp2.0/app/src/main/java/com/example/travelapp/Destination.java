package com.example.travelapp;

public class Destination {
    private int id;
    private String name;
    private String intro;
    private String detail;
    private String imageRes;
    private float rating;

    public Destination(int id, String name, String intro, String detail, String imageRes, float rating) {
        this.id = id;
        this.name = name;
        this.intro = intro;
        this.detail = detail;
        this.imageRes = imageRes;
        this.rating = rating;
    }

    // Getter
    public int getId() { return id; }
    public String getName() { return name; }
    public String getIntro() { return intro; }
    public String getDetail() { return detail; }
    public String getImageRes() { return imageRes; }
    public float getRating() { return rating; }
}