package com.example.travelapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import java.util.List;

public class DestinationAdapter extends BaseAdapter {

    private Context context;
    private List<Destination> dataList;

    public DestinationAdapter(Context context, List<Destination> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @Override
    public int getCount() {
        return dataList == null ? 0 : dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return dataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // 1. 加载布局
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_destination, parent, false);
        }

        // 2. 拿到当前行的数据
        final Destination item = dataList.get(position);

        // 3. 找到控件
        ImageView ivImg = convertView.findViewById(R.id.iv_item_img);
        TextView tvName = convertView.findViewById(R.id.tv_item_name);
        TextView tvIntro = convertView.findViewById(R.id.tv_item_intro);

        // 4. 设置列表页显示的文字
        tvName.setText(item.getName());
        tvIntro.setText(item.getIntro());

        // 5. 设置图片 & 计算图片ID
        // 获取图片资源ID (int类型)
        int resId = context.getResources().getIdentifier(item.getImageRes(), "drawable", context.getPackageName());

        // 如果找不到图，就用默认图标，防止报错
        final int finalImageId = (resId != 0) ? resId : R.mipmap.ic_launcher;

        if (resId != 0) {
            Glide.with(context).load(resId).into(ivImg);
        } else {
            ivImg.setImageResource(R.mipmap.ic_launcher);
        }

        //  6. 关键步骤：添加点击事件，跳转到详情页
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailActivity.class);

                intent.putExtra("title", item.getName());      // 传名字
                intent.putExtra("desc", item.getIntro());      // 传简介
                intent.putExtra("image_id", finalImageId);     // 传图片资源ID (int)
                intent.putExtra("score", 5.0f);                // 传个默认评分 (或者 item.getRating() 如果你有的话)

                // 启动跳转
                context.startAcmtivity(intent);
            }
        });

        return convertView;
    }
}