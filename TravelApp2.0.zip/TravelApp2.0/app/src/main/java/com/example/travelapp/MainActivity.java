package com.example.travelapp;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private ListView lvDestinations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvDestinations = findViewById(R.id.lv_destinations);

        MusicManager.getInstance().play(this);

        List<Map<String, Object>> list = new ArrayList<>();
        addDest(list, "京都古韵", "#宁静 #寺庙", R.drawable.p_kyoto, 4.9f, "在古老的寺庙中聆听风铃的声音。漫步于花见小路，感受千年古都的唐风宋韵，让心灵在茶道与禅意中得到彻底的放松...");
        addDest(list, "瑞士雪山", "#治愈 #纯净", R.drawable.p_swiss, 5.0f, "坐上红色的景观列车，穿梭在皑皑白雪与翠绿森林之间。呼吸阿尔卑斯山最纯净的空气，仿佛置身于现实版的童话世界...");
        addDest(list, "大理洱海", "#慢生活", R.drawable.p_dali, 4.8f, "去有风的地方，看苍山洱海，云卷云舒。租一辆单车环海骑行，在民宿的露台上发呆，享受没有快节奏的慢时光...");
        addDest(list, "马尔代夫", "#海岛 #度假", R.drawable.p_maldives, 4.7f, "上帝抛洒在人间的项链。住进水上屋，醒来就能直接跳进果冻色的海里。这里只需做两件事：看海，和放空...");

        //如果超过屏幕界面就开启滚轮
        SimpleAdapter adapter = new SimpleAdapter(
                this,
                list,
                R.layout.item_destination,
                new String[]{"img", "name", "tag"},
                new int[]{R.id.iv_item_img, R.id.tv_item_name, R.id.tv_item_intro}
        );
        lvDestinations.setAdapter(adapter);

        //景点跳转
        lvDestinations.setOnItemClickListener((parent, view, position, id) -> {
            Map<String, Object> item = list.get(position);
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);

            intent.putExtra("title", (String) item.get("name"));
            intent.putExtra("desc", (String) item.get("desc"));
            intent.putExtra("score", (float) item.get("rating"));
            intent.putExtra("image_id", (int) item.get("img"));

            startActivity(intent);
        });

        findViewById(R.id.btn_my_plans).setOnClickListener(v -> startActivity(new Intent(this, PlanActivity.class)));
        findViewById(R.id.btn_music).setOnClickListener(v -> startActivity(new Intent(this, MusicActivity.class)));
        findViewById(R.id.btn_about).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, MineActivity.class));
        });
        findViewById(R.id.cv_lucky_entry).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, LuckyActivity.class));
        });
        findViewById(R.id.btn_earth_mode).setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, EarthActivity.class)));
    }

    private void addDest(List<Map<String, Object>> list, String name, String tag, int img, float rating, String desc) {
        Map<String, Object> map = new HashMap<>();
        map.put("name", name);
        map.put("tag", tag);
        map.put("img", img);
        map.put("rating", rating);
        map.put("desc", desc);
        list.add(map);
    }
}