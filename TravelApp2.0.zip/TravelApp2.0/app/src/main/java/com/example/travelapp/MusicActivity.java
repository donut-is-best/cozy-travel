package com.example.travelapp;

import android.animation.ObjectAnimator;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;

public class MusicActivity extends AppCompatActivity {

    private SeekBar seekBar;
    private TextView tvCurrent, tvTotal;
    private TextView tvTitle, tvArtist; // 显示歌名和歌手

    private ImageView btnPlay; // 播放图标
    private View btnPlayContainer; // 播放按钮容器
    private ImageView ivRecord; // 唱片封面

    private ObjectAnimator rotateAnimator; // 旋转
    private Handler handler = new Handler();
    private SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss");

    // 定时更新进度条
    private Runnable updateThread = new Runnable() {
        @Override
        public void run() {
            MediaPlayer mp = MusicManager.getInstance().getMediaPlayer();
            if (mp != null && mp.isPlaying()) {
                seekBar.setProgress(mp.getCurrentPosition());
                tvCurrent.setText(timeFormat.format(mp.getCurrentPosition()));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        // 1. 绑定控件
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        seekBar = findViewById(R.id.sb_progress);
        tvCurrent = findViewById(R.id.tv_current_time);
        tvTotal = findViewById(R.id.tv_total_time);

        //歌名和歌手
        tvTitle = findViewById(R.id.tv_music_title);
        tvArtist = findViewById(R.id.tv_music_artist);

        btnPlay = findViewById(R.id.btn_play);
        btnPlayContainer = findViewById(R.id.cv_play_container);
        ivRecord = findViewById(R.id.iv_record);

        // 2. 初始化旋转动画
        rotateAnimator = ObjectAnimator.ofFloat(ivRecord, "rotation", 0f, 360f);
        rotateAnimator.setDuration(10000); // 10秒转一圈
        rotateAnimator.setRepeatCount(ObjectAnimator.INFINITE);
        rotateAnimator.setInterpolator(new LinearInterpolator());

        // 3. 进页面时，显示当前正在播放的歌)
        updateUI();

        // 如果进来时正在播放，图标设为暂停，动画开始
        if (MusicManager.getInstance().isPlaying()) {
            btnPlay.setImageResource(android.R.drawable.ic_media_pause);
            if (!rotateAnimator.isRunning()) rotateAnimator.start();
        } else {
            btnPlay.setImageResource(android.R.drawable.ic_media_play);
        }

        //  播放/暂停按钮逻辑
        btnPlayContainer.setOnClickListener(v -> {
            if (MusicManager.getInstance().isPlaying()) {
                // 暂停
                MusicManager.getInstance().pause();
                btnPlay.setImageResource(android.R.drawable.ic_media_play);
                rotateAnimator.pause();
            } else {
                // 播放
                MusicManager.getInstance().play(this);
                btnPlay.setImageResource(android.R.drawable.ic_media_pause);

                if (rotateAnimator.isPaused()) rotateAnimator.resume();
                else rotateAnimator.start();

                // 再次调用updateUI确保时长等信息正确
                updateUI();
            }
        });

        //  切歌：下一首
        findViewById(R.id.btn_next).setOnClickListener(v -> {
            MusicManager.getInstance().playNext(this);
            handleSongChange();
        });

        //  切歌：上一首
        findViewById(R.id.btn_prev).setOnClickListener(v -> {
            MusicManager.getInstance().playPrev(this);
            handleSongChange();
        });

        // 7. 进度条拖动
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) tvCurrent.setText(timeFormat.format(progress));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if(MusicManager.getInstance().getMediaPlayer() != null)
                    MusicManager.getInstance().getMediaPlayer().seekTo(seekBar.getProgress());
            }
        });

        handler.post(updateThread);
    }

    // 处理切歌后的逻辑
    private void handleSongChange() {
        updateUI(); // 换图、换字
        btnPlay.setImageResource(android.R.drawable.ic_media_pause); // 图标变暂停(代表正在播)
        rotateAnimator.start(); // 动画开始
    }

    // 根据当前歌曲更新界面
    private void updateUI() {
        // 从 MusicManager 获取当前歌曲对象
        Song song = MusicManager.getInstance().getCurrentSong();

        if (song != null) {
            // 1. 设置歌名和歌手
            tvTitle.setText(song.getTitle());
            tvArtist.setText(song.getArtist());

            // 2. 设置封面图
            ivRecord.setImageResource(song.getCoverResId());

            // 3. 设置进度条最大值
            MediaPlayer mp = MusicManager.getInstance().getMediaPlayer();
            if (mp != null) {
                seekBar.setMax(mp.getDuration());
                tvTotal.setText(timeFormat.format(mp.getDuration()));
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateThread);
    }
}