package com.example.travelapp;
import android.content.Context;
import android.media.MediaPlayer;
import java.util.ArrayList;
import java.util.List;

public class MusicManager {
    private static MusicManager instance;
    private MediaPlayer mediaPlayer;
    private List<Song> playlist = new ArrayList<>();
    private int currentIndex = 0;
    public static MusicManager getInstance() {
        if (instance == null) instance = new MusicManager();
        return instance;
    }

    // 初始化歌单
    private MusicManager() {
        playlist.add(new Song("We Don't Talk Anymore", "Charlie Puth", R.raw.song1, R.drawable.music_cover1));
        playlist.add(new Song("Die For You", "The Weeknd", R.raw.song2, R.drawable.music_cover2));
        playlist.add(new Song("The Other Side Of Paradise", "Glass Animals", R.raw.song3, R.drawable.music_cover3));
    }

    public Song getCurrentSong() {
        if (playlist.isEmpty()) return null;
        return playlist.get(currentIndex);
    }

    public void play(Context context) {
        if (playlist.isEmpty()) return;

        if (mediaPlayer == null) {
            playSong(context, playlist.get(currentIndex));
        } else if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    private void playSong(Context context, Song song) {
        stop(); // 切歌前先停止
        try {
            mediaPlayer = MediaPlayer.create(context, song.getResId());
            if (mediaPlayer == null) return;
            mediaPlayer.setLooping(true);
            mediaPlayer.start();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void playNext(Context context) {
        currentIndex = (currentIndex + 1) % playlist.size();
        playSong(context, playlist.get(currentIndex));
    }

    public void playPrev(Context context) {
        currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
        playSong(context, playlist.get(currentIndex));
    }

    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) mediaPlayer.pause();
    }

    public void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    public MediaPlayer getMediaPlayer() { return mediaPlayer; }
    public boolean isPlaying() { return mediaPlayer != null && mediaPlayer.isPlaying(); }
}