package com.example.travelapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import cn.bmob.v3.BmobUser;

public class MineActivity extends AppCompatActivity {

    private TextView tvUsername, tvUserStatus;
    private Button btnLogin;
    private ImageView ivAvatar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine);

        // 绑定控件
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
        tvUsername = findViewById(R.id.tv_username);
        tvUserStatus = findViewById(R.id.tv_user_status);
        btnLogin = findViewById(R.id.btn_login);
        ivAvatar = findViewById(R.id.iv_avatar);

        // 绑定菜单
        findViewById(R.id.btn_my_plans).setOnClickListener(v -> startActivity(new Intent(this, PlanActivity.class)));
        findViewById(R.id.btn_about).setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        findViewById(R.id.btn_my_notes).setOnClickListener(v -> Toast.makeText(this, "笔记功能即将上线", Toast.LENGTH_SHORT).show());

        // 按钮点击逻辑
        btnLogin.setOnClickListener(v -> {
            if (BmobUser.isLogin()) {
                BmobUser.logOut();
                updateUI();
                Toast.makeText(this, "已退出登录", Toast.LENGTH_SHORT).show();
            } else {
                startActivity(new Intent(this, LoginActivity.class));
            }
        });

        // 首次进入也刷新一次
        updateUI();
    }

    // 强制重新读取状态
    @Override
    protected void onResume() {
        super.onResume();
        // 强制刷新
        updateUI();
    }

    private void updateUI() {
        BmobUser user = BmobUser.getCurrentUser();

        // 判断是否登录
        if (BmobUser.isLogin()) {
            // === 已登录 ===
            String name = (user != null) ? user.getUsername() : "未知用户";
            tvUsername.setText(name);

            tvUserStatus.setText("状态：在线 ✅");

            btnLogin.setText("退出登录");

            // ivAvatar.setImageResource(R.drawable.avatar);

        } else {
            // === 未登录 ===
            tvUsername.setText("未登录");
            tvUserStatus.setText("请登录");
            btnLogin.setText("立即登录");
        }
    }
}