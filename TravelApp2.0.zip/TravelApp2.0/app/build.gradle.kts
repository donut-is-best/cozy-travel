plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    id("kotlin-kapt") // Kotlin DSL 写法：括号包裹，不是 id 'kotlin-kapt'
}

android {
    namespace = "com.example.travelapp"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        applicationId = "com.example.travelapp"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    dependencies {
        // === Android 核心库 (保留原本的) ===
        implementation("androidx.appcompat:appcompat:1.6.1")
        implementation("com.google.android.material:material:1.11.0")
        implementation("androidx.constraintlayout:constraintlayout:2.1.4")
        testImplementation("junit:junit:4.13.2")
        androidTestImplementation("androidx.test.ext:junit:1.1.5")
        androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

        // === 我们之前加的 UI 库 (保留) ===
        implementation("androidx.cardview:cardview:1.0.0")
        implementation("com.github.bumptech.glide:glide:4.12.0")
        // Glide 的注解处理器 (如果有用的话)
        annotationProcessor("com.github.bumptech.glide:compiler:4.12.0")

        // =======================================================
        // 🔴 Bmob 后端云 SDK (新增部分)
        // =======================================================
        implementation("io.github.bmob:android-sdk:3.9.6")
        implementation("io.reactivex.rxjava2:rxjava:2.2.21")
        implementation("io.reactivex.rxjava2:rxandroid:2.1.1")
        implementation("com.squareup.okhttp3:okhttp:4.9.0")
        implementation("com.squareup.okio:okio:2.8.0")
        implementation("com.google.code.gson:gson:2.8.9")
    }
}